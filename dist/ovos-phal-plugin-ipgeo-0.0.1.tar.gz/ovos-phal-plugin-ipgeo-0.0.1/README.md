# PHAL plugin - IPGeo
Provides geolocation information via the Messagebus.